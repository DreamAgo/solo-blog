title: '[Springboot]同时配置MultipartConfigElement和CommonsMultipartResolver文件上传会失败'
date: '2019-09-30 02:06:34'
updated: '2019-09-30 02:06:34'
tags: [SpringBoot, 笔记, 知识点]
permalink: /articles/2019/09/29/1569779588770.html
---
# 起因
>公司项目使用了百度编辑器，因为以前自定义上传接口不满足并且逻辑很不合理，今天打算回炉重造结果遇到几个坑在此记录一下
1、百度编辑器与SpringMVC接受参数`MultipartFile`冲突导致百度编辑无法上传文件

> >解决办法：

```JAVA
@Component
public class CustomMultipartResolver extends CommonsMultipartResolver {
    @Override
    public boolean isMultipart(HttpServletRequest request) {
        String url = request.getRequestURI();
        if (url!=null && url.contains("jsp/editor.do")) {
            return false;
        } else {
            return super.isMultipart(request);
        }
    }
}
```
>>`jsp/editor.do`换成百度编辑上传接口

>2、`spring.servlet.multipart.enabled`启用SpringMVC的接口上传文件报错
>>原因:看`org.springframework.boot.autoconfigure.web.servlet.MultipartAutoConfiguration`类有条`@ConditionalOnProperty(prefix = "spring.servlet.multipart", name = "enabled", matchIfMissing = true)`注解，意思就是spring.servlet.multipart.enabled的时候启用，之后会创建一个`MultipartConfigElement`Bean,原因就在于自定义`CommonsMultipartResolver `不能和`MultipartConfigElement`同时配置
解决办法:单独在自定义`CommonsMultipartResolver `中配置文件上传大小等参数

