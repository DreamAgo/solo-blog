title: '[C#]将状态信息放置在控制台最下面'
date: '2019-02-07 01:34:03'
updated: '2019-02-07 16:10:23'
tags: [笔记, .NET]
permalink: /articles/2019/02/06/1549473707457.html
---
** ConsoleInput**

```java
public class ConsoleInput
    {
        private string inputString = string.Empty;
        private readonly List<string> inputHistory = new List<string>();
        internal readonly string[] StatusTextLeft = { string.Empty, string.Empty, string.Empty, string.Empty };
        internal readonly string[] StatusTextRight = { string.Empty, string.Empty, string.Empty, string.Empty };
        internal readonly ConsoleColor[] StatusTextLeftColor = { ConsoleColor.White, ConsoleColor.White, ConsoleColor.White, ConsoleColor.White };
        internal readonly ConsoleColor[] StatusTextRightColor = { ConsoleColor.White, ConsoleColor.White, ConsoleColor.White, ConsoleColor.White };
        public int LineWidth => Console.BufferWidth;
        public void ClearLine(int numLines)
        {
            Console.CursorLeft = 0;
            Console.Write(new string(' ', LineWidth * numLines));
            Console.CursorTop = Console.CursorTop - numLines;
            Console.CursorLeft = 0;
        }

        public void RedrawInputLine()
        {
            try
            {
                Console.CursorTop = Console.CursorTop + 1;
                for (int i = 0; i < StatusTextLeft.Length; i++)
                {
                    Console.CursorLeft = 0;
                    Console.ForegroundColor = StatusTextLeftColor[i];
                    Console.Write(StatusTextLeft[i].Substring(0, Math.Min(StatusTextLeft[i].Length, LineWidth - 1)));
                    Console.ForegroundColor = StatusTextRightColor[i];
                    Console.Write(StatusTextRight[i].PadRight(LineWidth));
                }
                Console.CursorTop = Console.CursorTop - StatusTextLeft.Length -1;
                Console.CursorLeft = 0;
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Green;
                ClearLine(1);
                if (inputString.Length == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    return;
                }
                Console.Write(inputString.Length >= LineWidth - 2 ? inputString.Substring(inputString.Length - (LineWidth - 2)) : inputString);
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            catch (Exception e)
            {
                Console.WriteLine("RedrawInputLine: " + e);

            }
        }

        public void Update()
        {

            try
            {
                if (!Console.KeyAvailable)
                {
                    return;
                }
            }
            catch (Exception)
            {
                return;
            }
            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey();
            if (consoleKeyInfo.Key == ConsoleKey.Enter)
            {
                Console.WriteLine(inputString);
                inputString = string.Empty;
                RedrawInputLine();
                return;
            }
            inputString = string.Concat(inputString, consoleKeyInfo.KeyChar);
            RedrawInputLine();
        }
    }
```
	
	
**Main**
```java
private static ConsoleInput consoleInput;
        private static string GetStatusValue(string status) => status != null ? status ?? string.Empty : "";
        private static string GetStatusRight(int leftLength, string right) => leftLength >= right.Length ? string.Empty : right.Substring(leftLength);
        static void Main(string[] args)
        {
            consoleInput = new ConsoleInput();
            Console.WriteLine("load............ing...............");
            Console.WriteLine("ConsoleInput");
           int j=0;
            while (true)
            {
                j++;
                for (int i = 0; i < consoleInput.StatusTextLeft.Length; i++)
                {
                    consoleInput.StatusTextLeft[i] = GetStatusValue($"{j}{i}");//赋值
                }
                j++;
                for (int i = 0; i < consoleInput.StatusTextRight.Length; i++)
                {
                    consoleInput.StatusTextRight[i] = GetStatusRight(consoleInput.StatusTextLeft[i].Length, GetStatusValue($"{j}{i}").PadLeft(consoleInput.LineWidth - 1));//右边计算位置再赋值
                }
                consoleInput.Update();
            }
        }
```
		
		
![bgif](http://pmikev4i6.bkt.clouddn.com//file/2019/02/04259cd0aa6c461fa9185aa8008b535f_b.gif) 


