title: 【React Native】React Native输入框输入完之后点击按钮无效，会先把键盘收起来
date: '2019-07-14 19:54:36'
updated: '2019-07-14 19:54:36'
tags: [ReactNative]
permalink: /articles/2019/07/14/1563105184763.html
---
使用了KeyboardAwareScrollView之后输入框输入完点击旁边的按钮发现没有反应，先是把键盘收起来，再点按钮才有反应，挺影响操作体验
解决办法就是
```
<KeyboardAwareScrollView  keyboardShouldPersistTaps="handled">

<View  style={styles.backCommand}>

<View  style={{ flex:  7 }}>

<Input

returnKeyType="send"

value={this.state.command}

onChangeText={command  => {

this.setState({ command });

}}

placeholderTextColor="#fff"

inputContainerStyle={styles.inputCommand}

inputStyle={{ color:  '#fff' }}

placeholder="输入指令"

onSubmitEditing={this._send.bind(this)}

/>

</View>

<View  style={{ flex:  2 }}>

<Button  buttonStyle={styles.sendButton}  title="发送"  onPress={this._send.bind(this)}  />

</View>

</View>

</KeyboardAwareScrollView>
```
加上一段 ``keyboardShouldPersistTaps="handled"``属性即可