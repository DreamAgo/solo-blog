title: '[SpringBoot]SpringBoot整合Mybatis(SSM开发环境搭建)'
date: '2019-03-26 02:27:10'
updated: '2019-03-26 02:27:54'
tags: [Mybatis, SpringBoot]
permalink: /articles/2019/03/25/1553534613838.html
---
# SpringBoot介绍
> Spring Boot是为了简化Spring应用的创建、运行、调试、部署等而出现的，使用它可以做到专注于Spring应用的开发，而无需过多关注XML的配置。
简单来说，它提供了一堆依赖打包，并已经按照使用习惯解决了依赖问题。

# 搭建SpringBoot Web环境
> 
最新版IDEA已经支持SpringBoot，可以使用SpringBoot Initializr生成。如果使用其他IDE也可以进https://start.spring.io 生成可用的工程。

>
![image.png](https://img.hacpai.com/file/2019/03/image-859ecb3b.png)
---
这里直接点击Next。
---
![image.png](https://img.hacpai.com/file/2019/03/image-3a0a623a.png)
---
这里就和创建普通maven项目差不多，但是这个可以选择生成的语言，默认Java。
---
![image.png](https://img.hacpai.com/file/2019/03/image-6f72ede4.png)
---
这里就是可以选择的模板，我们选Web，之后就是选择工程路径了。

>
创建完成之后就是这样子了
---
![image.png](https://img.hacpai.com/file/2019/03/image-8bc8d418.png)
---
`UserApplication`为应用入口
---
![image.png](https://img.hacpai.com/file/2019/03/image-7224c7c9.png)
---
创建一个`HelloController`和一个`hello`方法并添加`@RequestMapping("/hello")`注释然后启动应用，在浏览器输入http://127.0.0.1:8080/hello 

>
![image.png](https://img.hacpai.com/file/2019/03/image-92123eda.png)
---
一个SpringBoot简单应用就搭建完了，接下来就是整合Mybits了，需要在pom.xml添加依赖

>
``` 
        <!--Mybatis 支持-->
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>1.1.1</version>
        </dependency>
        <!--Mysql驱动-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>5.1.31</version>
            <scope>runtime</scope>
        </dependency>
```
---
然后将资源文件application.properties改成application.yml文件格式，yml格式好处很多，其中之一就是结构分明，一眼就能看懂，下面是数据源配置

>
```
spring:
  datasource:
    url: jdbc:mysql:///mybits?useUnicode=true&characterEncoding=utf8
    username: root
    password: 123456
    driver-class-name: com.mysql.jdbc.Driver
```
---
Pojo
---
``` Java
public class School {
    private int id;
    private String name;
    private String addres;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAddres() {
        return addres;
    }
    public void setAddres(String addres) {
        this.addres = addres;
    }
}
```
---
Mapper
---
```
@Mapper
public interface SchoolMapper {
    @Select({"SELECT *",
            "FROM school",
            "WHERE id = #{value}"})
    School findById(int id);
}
```
---
Service
---
```
public interface SchoolService {
    /**
     * 通过ID获取学校
     * @param id
     * @return
     */
    School findById(Integer id);
}
```
```
@Service
public class SchoolServiceImpl implements SchoolService {
   @Autowired
    private SchoolMapper schoolMapper;
    @Override
    public School findById(Integer id) {
        return schoolMapper.findById(id);
    }
}
```
---
这里遇到一个问题就是使用`@Autowired`注解注入mapper时IDEA会提示找不到这个bean,这时需要安装mybits plugin安装方法百度即可
在application.yml中增加配置：
```
mybatis: 
  mapperLocations: classpath:mapper/*.xml
  typeAliasesPackage: cn.loverot.hub.user.mapper
```
除了上面常见的两项配置，还有：
mybatis.config：mybatis-config.xml配置文件的路径
mybatis.typeHandlersPackage：扫描typeHandlers的包
mybatis.checkConfigLocation：检查配置文件是否存在
mybatis.executorType：设置执行模式（SIMPLE, REUSE, BATCH），默认为SIMPLE
>
---
修改HelloController
---
```
@RestController
public class HelloController {
    @Autowired
    private SchoolService schoolService;
    @RequestMapping("/hello")
    public String hello(){
        School school = schoolService.findById(1);
        return "学校名："+school.getName();
    }
}
```
---
![image.png](https://img.hacpai.com/file/2019/03/image-ce4d95bd.png)
---
数据表
---
![image.png](https://img.hacpai.com/file/2019/03/image-4361f68f.png)
---
到这环境就已经整合完成了。工程地址：https://github.com/huiseDT/SpringBootDemo

