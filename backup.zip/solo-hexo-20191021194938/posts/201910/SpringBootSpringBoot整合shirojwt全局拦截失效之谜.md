title: '[SpringBoot]SpringBoot整合shiro+jwt全局拦截失效之谜'
date: '2019-10-20 15:56:08'
updated: '2019-10-20 15:56:08'
tags: [SpringBoot]
permalink: /articles/2019/10/19/1571505432202.html
---
今天在整合shiro+jwt的登录控制的时候发现在自定义`Filter`中调用`executeLogin`方法之后`AuthenticationException`异常类抛出的时候全局捕捉类无法捕获,在此之前自定义异常类是能正常捕获的
>异常抛出

```java
  String token = (String) auth.getCredentials();
        if (StringUtils.isEmpty(token)) {
            throw new AuthenticationException("token为空!");
        }
```
> 全局捕捉方法

```java
 @ExceptionHandler(value = AuthenticationException.class)
    public ResultResponse handleAuthenticationException(AuthenticationException e) {
        log.debug("AuthenticationException", e);
        return ResultResponse.fail().message(e.getMessage());
    }
```
猜想:可能是添加过滤器是new出来的所以不再spring管理范围内导致无法捕获

```java
  //获取filters
        Map<String, Filter> filters = shiroFilterFactoryBean.getFilters();
        //将自定义 的Filter注入shiroFilter中
        filters.put("user", new JwtFilter());
```

>解决办法:

```
@Override
	protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
		try {
			executeLogin(request, response);
			return true;
		} catch (Exception e) {
			//解决后台报错
			PrintWriter writer =null;
			try {
				response.setContentType("text/html;charset=utf-8");
				writer = response.getWriter();
				writer.write(JSON.toJSONString(ResultResponse.unAuth().message(e.getMessage())));
			} catch (IOException e1) {
				writer.write(JSON.toJSONString(ResultResponse.fail().message(e.getMessage())));
			}
			return false;
		}
	}
```
使用try处理















