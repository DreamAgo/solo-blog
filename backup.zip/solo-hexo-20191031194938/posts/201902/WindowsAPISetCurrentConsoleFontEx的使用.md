title: '[Windows API]SetCurrentConsoleFontEx的使用'
date: '2019-02-14 05:07:21'
updated: '2019-02-14 05:07:21'
tags: [Windows, 笔记]
permalink: /articles/2019/02/13/1550090862509.html
---

今天写了个控制台程序，本机测试一切正常，但是放进服务器发现中文全都乱码。找了很久的问题发现在服务器中控制台为GBK编码，输出是UTF-8编码。控制台改为UTF-8之后服务器上的点阵字体是乱码
![imagepng](http://oss.loverot.cn//file/2019/02/ef01e58c5fc94e59aec953c3f4c00062_image.png) 

改为Consolas就好了。因为程序用的人挺多，为了提高用户体验所以得自己动手了。办法有两种一种是修改注册表改编码和字体这种百度上面很多，但是只能先启动程序这个时候会乱码，修改了重启之后才生效。另一种就是用Windows提供的API直接修改。找了一下API发现有个SetCurrentConsoleFontEx函数可以修改字体，但是百度了半天也没看见C#的代码，只能使出科学上网工具Google一下，输入这个函数就出现了C#的候选词（Google牛逼）然后就找到了后面的代码，但是调试了半天发现修改成Consolas,要么框框小字体小，要么变成Lucida Console丑丑的字体。又是调试了半天发现必须先修改字体再改控制台页码....而我一直是先改控制台页码在前，主要是因为之前手动改不先修改编码字体都没有的。下面就是代码
```
 public static class ConsoleHelper
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal unsafe struct CONSOLE_FONT_INFO_EX
        {
            internal uint cbSize;
            internal uint nFont;
            internal COORD dwFontSize;
            internal int FontFamily;
            internal int FontWeight;
            internal fixed char FaceName[LF_FACESIZE];
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct COORD
        {
            internal short X;
            internal short Y;

            internal COORD(short x, short y)
            {
                X = x;
                Y = y;
            }
        }
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr GetStdHandle(int nStdHandle);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool GetCurrentConsoleFontEx(
               IntPtr consoleOutput,
               bool maximumWindow,
               ref CONSOLE_FONT_INFO_EX lpConsoleCurrentFontEx);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool SetCurrentConsoleFontEx(
               IntPtr consoleOutput,
               bool maximumWindow,
             ref CONSOLE_FONT_INFO_EX consoleCurrentFontEx);

        private const int STD_OUTPUT_HANDLE = -11;
        private const int TMPF_TRUETYPE = 4;
        private const int LF_FACESIZE = 32;
        private static IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

        public static bool SetConsoleFont(string fontName = "Consolas")
        {
            unsafe
            {
                //IntPtr hnd = GetStdHandle(STD_OUTPUT_HANDLE);
                //if (hnd != INVALID_HANDLE_VALUE)
                //{
                //    CONSOLE_FONT_INFO_EX info = new CONSOLE_FONT_INFO_EX();
                //    info.cbSize = (uint)Marshal.SizeOf(info);

                //    // Set console font to Lucida Console.
                //    CONSOLE_FONT_INFO_EX newInfo = new CONSOLE_FONT_INFO_EX();
                //    newInfo.cbSize = (uint)Marshal.SizeOf(newInfo);
                //    newInfo.FontFamily = TMPF_TRUETYPE;
                //    IntPtr ptr = new IntPtr(newInfo.FaceName);
                //    Marshal.Copy(fontName.ToCharArray(), 0, ptr, fontName.Length);
                //    Console.WriteLine($"{info.dwFontSize.X},{info.dwFontSize.Y},{info.FontWeight}");
                //    // Get some settings from current font.
                //    newInfo.dwFontSize = new COORD(info.dwFontSize.X, info.dwFontSize.Y);
                //    newInfo.FontWeight = info.FontWeight;
                //    return SetCurrentConsoleFontEx(hnd, true, ref newInfo);
                //}
                IntPtr hnd = GetStdHandle(STD_OUTPUT_HANDLE);
                if (hnd != INVALID_HANDLE_VALUE)
                {

                    // Set console font to Lucida Console.
                    CONSOLE_FONT_INFO_EX newInfo = new CONSOLE_FONT_INFO_EX();
                    newInfo.cbSize = (uint)Marshal.SizeOf(newInfo);
                    newInfo.FontFamily = TMPF_TRUETYPE;
                    IntPtr ptr = new IntPtr(newInfo.FaceName);
                    Marshal.Copy(fontName.ToCharArray(), 0, ptr, fontName.Length);

                    // Get some settings from current font.
                    newInfo.dwFontSize = new COORD(12, 16);
                    newInfo.FontWeight = 400;
                    return SetCurrentConsoleFontEx(hnd, false, ref newInfo);
                }
                return false;
            }
        }
    }
```

```
class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("中文测试");
            ConsoleHelper.SetConsoleFont();
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("中文测试");
            Console.Read();
        }
    }
```
![imagepng](http://oss.loverot.cn//file/2019/02/4fab2d4f24124bcc96535cefade9cdc2_image.png) 


