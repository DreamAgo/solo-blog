title: '[MyBatis]MyBatis Generator逆向工程生成一对一、一对多的方法'
date: '2019-03-13 23:06:03'
updated: '2019-03-26 02:29:24'
tags: [java, Mysql, Mybatis]
permalink: /articles/2019/03/13/1552489229848.html
---
MyBatis官方的目前还不支持生成一对一关系的类，网上有大牛写了个插件使得Mybits Generator可以生成各种关系，在这记录下生成配置与方法
以下是配置信息
***
```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE generatorConfiguration
        PUBLIC "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN"
        "http://mybatis.org/dtd/mybatis-generator-config_1_0.dtd">

<generatorConfiguration>
    <context id="testTables" targetRuntime="MyBatis3">
        <!-- 生成一对一配置 -->
        <plugin type="cc.bandaotixi.plugins.OneToOnePlugin" />
        <!-- 生成一对多配置 -->
        <plugin type="cc.bandaotixi.plugins.OneToManyPlugin" />
        <!-- 生成批量配置 -->
        <plugin type="cc.bandaotixi.plugins.BatchInsertPlugin" />
        <plugin type="cc.bandaotixi.plugins.BatchUpdatePlugin" />

        <commentGenerator type="cc.bandaotixi.plugins.BDTCommentGenerator">
            <property name="javaFileEncoding" value="UTF-8"/>
            <property name="suppressDate" value="true"/>
            <property name="suppressAllComments" value="false" />
        </commentGenerator>
        <!--mysql数据库连接的信息：驱动类、连接地址、用户名、密码 -->
        <jdbcConnection driverClass="com.mysql.jdbc.Driver"
                        connectionURL="jdbc:mysql://localhost:3306/dorm" userId="root"
                        password="19980312a.">
        </jdbcConnection>

        <!--oracle配置-->
        <!-- <jdbcConnection driverClass="oracle.jdbc.OracleDriver" connectionURL="jdbc:oracle:thin:@127.0.0.1:1521:yycg"
            userId="yycg"
            password="yycg">
        </jdbcConnection> -->

        <!-- 默认false，把JDBC DECIMAL 和 NUMERIC 类型解析为 Integer，
        为 true时把JDBC DECIMAL和NUMERIC类型解析为java.math.BigDecimal -->
        <javaTypeResolver>
            <property name="forceBigDecimals" value="false"/>
        </javaTypeResolver>

        <!-- targetProject:生成model类的位置，重要！！ -->
        <javaModelGenerator targetPackage="cn.loverot.hub.pojo" targetProject=".\src\main\java">
            <!-- enableSubPackages:是否让schema作为包的后缀 -->
            <property name="enableSubPackages" value="false"/>
            <!-- 从数据库返回的值被清理前后的空格 -->
            <property name="trimStrings" value="true"/>
        </javaModelGenerator>

        <!-- targetProject:mapper映射xml文件生成的位置，重要！！ -->
        <sqlMapGenerator targetPackage="cn.loverot.hub.mapper"
                         targetProject=".\src\main\java">
            <property name="enableSubPackages" value="false"/>
        </sqlMapGenerator>

        <!-- targetPackage：mapper接口生成的位置，重要！！ -->
        <javaClientGenerator type="XMLMAPPER"
                             targetPackage="cn.loverot.hub.mapper"
                             targetProject=".\src\main\java">
            <property name="enableSubPackages" value="false"/>
        </javaClientGenerator>

        <!-- 指定数据库表，要生成哪些表，就写哪些表，要和数据库中对应，不能写错！ -->
        <table tableName="user" domainObjectName="User">
        </table>
        <table tableName="student" domainObjectName="Student">
            <oneToOne mappingTable="user" column="user_id" joinColumn="user_id" />
            <oneToOne mappingTable="check_in" column="student_id" joinColumn="student_id" />
        </table>
        <table tableName="dormitory" domainObjectName="Dormitory">
            <oneToMany mappingTable="dormitory_manager" column="id" joinColumn="dormitory_id" />
            <oneToMany mappingTable="bedroom" column="id" joinColumn="dormitory_id" />
        </table>
        <table tableName="dormitory_manager" domainObjectName="DormitoryManager">
            <oneToOne mappingTable="user" column="user_id" joinColumn="id" />
            <oneToOne mappingTable="dormitory" column="dormitory_id" joinColumn="id" />
        </table>
        <table tableName="bedroom" domainObjectName="Bedroom">
            <oneToOne mappingTable="check_in" column="id" joinColumn="bedroom_id" />
            <oneToOne mappingTable="dormitory" column="dormitory_id" joinColumn="id" />
            <oneToMany mappingTable="maintenance_record" column="id" joinColumn="bedroom_id" />
        </table>
        <table tableName="check_in" domainObjectName="CheckIn">
            <oneToOne mappingTable="student" column="student_id" joinColumn="student_id" />
            <oneToOne mappingTable="bedroom" column="bedroom_id" joinColumn="id" />
        </table>
        <table tableName="maintenance_record" domainObjectName="MaintenanceRecord">
            <oneToOne mappingTable="bedroom" column="bedroom_id" joinColumn="id" />
        </table>
    </context>
</generatorConfiguration>
```
* domainObjectName 必须填写不然会报空引用
* column是当前表中字段，joinColumn是关联表的字段
*** 
下面是生成代码
***
```
 public void Main()
    {
        List<String> warnings = new ArrayList<String>();
        boolean overwrite = true;
        String genCfg = "/generatorConfig.xml";
        File configFile = new File(t.class.getResource(genCfg).getFile());
        ConfigurationParser cp = new ConfigurationParser(warnings);
        Configuration config = null;
        try {

            config = cp.parseConfiguration(configFile);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XMLParserException e) {
            e.printStackTrace();
        }
        DefaultShellCallback callback = new DefaultShellCallback(overwrite);
        MyBatisGenerator myBatisGenerator = null;
        try {
            myBatisGenerator = new MyBatisGenerator(config, callback, warnings);

        } catch (InvalidConfigurationException e) {
            e.printStackTrace();
        }
        try {
            myBatisGenerator.generate(null);

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("代码反向生成完毕-----");

    }
```
运行之后就生成完毕了