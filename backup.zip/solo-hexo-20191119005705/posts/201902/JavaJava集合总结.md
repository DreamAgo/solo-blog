title: '[Java]Java集合总结'
date: '2019-02-28 17:33:37'
updated: '2019-02-28 17:33:37'
tags: [java, 知识点]
permalink: /articles/2019/02/24/1551001070247.html
---

 1.  集合的由来
    > 集合是为了满足我们在程序开发中存储不同类型对象而诞生的。相比于数组，集合更为灵活，数组只能存放指定类型且大小固定，而集合恰弥补了这些缺点：可扩充、可存放不同类型。 
2. 集合是什么
    >Java集合类存放于 java.util 包中，是一个用来存放对象的容器。
集合只能存放对象，每种基本类型在java中都有对应的类，
如：`int`>`Integer`、`char`>`Character` 等，所以集合中只是存放对象的引用，对象本身还在存放在堆内存中。
如：
``` java
class  T

{

    public T(int i) {

        this.i = i;

    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    private int i;
}
```

```java
 public static void main(String[] args) {


        List<T> l= new ArrayList();

        T t=new T(1);

        System.out.println(t.getI());

        l.add(t);

        l.get(0).setI(2);
        System.out.println(t.getI());

    }
```
输出
`1
`
`2`
> 可以看见改变了对象内的变量

3.集合框架图 
![20160124221843905.jpg](https://img.hacpai.com/file/2019/02/20160124221843905-70732f35.jpg)
> 来源至：https://blog.csdn.net/u010887744/article/details/50575735
> 集合（容器）分两大类，一个是继承 Collection接口，另一个是继承map接口
首先我们讲下继承Collection的集合：
>
* Collection继承自Iterable`public interface Collection<E> extends Iterable<E>`
* Iterables封装了`iterator`（迭代器）![image.png](https://img.hacpai.com/file/2019/02/image-d5b05a4f.png)
所以继承了Collection的类都能使用iterator
> 
- iterator
`Object next()`：返回迭代器刚越过的元素的引用，返回值是 Object，需要强制转换成自己需要的类型(只能往后遍历，遍历过的元素不会再被遍历到)
`boolean hasNext()`：判断容器内是否还有可供访问的元素
`void remove()`：删除迭代器刚越过的元素
-----
Map用法
-----
* 初始化
`Map<String, String> map = ``new``HashMap<String, String>();`
* 插入
`map.put(``"key1"``, ``"value1"``);`
* 读取
`map.get(``"key1"``)`
* 移除
`map.remove(``"key1"``);`
* 清空
`map.clear();`
* 使用entrySet()遍历
```java
for (Map.Entry<String, String> entry : map.entrySet()) {
    System.out.println(entry.getKey() + " ：" + entry.getValue());
}```

* 迭代器遍历
    * 使用keySet()遍历

``` java
Iterator<String> iterator = map.keySet().iterator();
while (iterator.hasNext()) {
    String key = iterator.next();
    System.out.println(key + "　：" + map.get(key));
}
```
    * 使用entrySet()遍历

```java
Iterator<Map.Entry<String, String>> iterator = map.entrySet().iterator();
while (iterator.hasNext()) {
    Map.Entry<String, String> entry = iterator.next();
    System.out.println(entry.getKey() + "　：" + entry.getValue());
```