title: '[笔记]Centos7下Docker的安装教程'
date: '2019-03-23 17:49:59'
updated: '2019-03-23 17:49:59'
tags: [Docker, Linux]
permalink: /articles/2019/03/23/1553334199771.html
---
今天刚买一台云服务器，打算装个Docker将我之前的验证服务器迁移到这，以下记录安装过程：
**如果以前安装过docker或带有老版本的docker需要使用以下指令卸载**
```
yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-selinux \
                  docker-engine-selinux \
                  docker-engine
```
**然后安装一些系统工具**
`yum install -y yum-utils device-mapper-persistent-data lvm2`
**修改下载源**
`yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo`
**更新缓存**
`yum makecache fast`
**安装**
`yum -y install docker-ce`
**启动**
`systemctl start docker`
不出意外到这一步就已经可以使用docker了