title: '[Mybatis]Mybatis的单元测试之自动注入'
date: '2019-02-26 18:06:19'
updated: '2019-02-26 18:06:19'
tags: [java, Mybatis]
permalink: /articles/2019/02/26/1551175569626.html
---
记录一下
```java
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:spring/applicationContext-*.xml")
public class ServersServiceImplTest {

    @Autowired
    ServersService service;
    @Test
    public void getServers() {
        List<Servers> servers = service.getServers(10);
        System.out.println(servers.size());
    }
}
```