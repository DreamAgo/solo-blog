title: '[SpringBoot]整合springboot+shiro+redis出现Cacheable注解无效的解决办法'
date: '2019-10-20 17:26:36'
updated: '2019-10-20 17:26:36'
tags: [SpringBoot]
permalink: /articles/2019/10/20/1571563508137.html
---
在我做项目的时候，在Spring Boot 中对Shiro和Redis进行了整合，但实际发现Spring boot中Shiro和Redis集成后，Spring的@cacheble注解无效。

出现的情况如下：

如果只是Spring boot和Redis集成，那么@cacheble可用，会把缓存数据写入Redis。
如果只是Spring boot和Shiro集成，然后用Spring cache抽象出cachemanager，作为Shiro的缓存。控制台未报错，Shiro的认证信息会存入Redis，但出现@cacheble注解无效，即@Cacheble注解的方法的返回值未存入Redis。如果果将Shiro的@Configuration注解去掉，即不用Shiro，@Cacheble可用。
解决方法如下： 

```
public class ShiroRealm extends AuthorizingRealm {


    @Autowired
    @Lazy
    private IUserService userService;
    @Autowired
    @Lazy
    private IRoleService roleService;
    @Autowired
    @Lazy
    private IMenuService menuService;
    @Autowired
    @Lazy
    private RedisUtil redisUtil;
```
在ShiroRealm的@Autowired注解下面加上@Lazy

测试成功添加缓存至redis
![image.png](https://img.hacpai.com/file/2019/10/image-ad0c7fe5.png)


原文链接：https://blog.csdn.net/cckevincyh/article/details/79637063