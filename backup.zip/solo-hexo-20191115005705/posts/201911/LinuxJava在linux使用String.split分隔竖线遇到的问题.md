title: '[Linux]Java在linux使用String.split分隔|(竖线)遇到的问题'
date: '2019-11-08 17:49:27'
updated: '2019-11-08 17:49:27'
tags: [Linux, java]
permalink: /articles/2019/11/08/1573206567533.html
---
今天在排查BUG时发现一个神奇的问题，一段字符串路径使用|分隔居然变成了单个字符，原因就在于linux对|有特殊含义导致的
解决办法：String.split("\\|")在|前面加上\\就行了。
