title: '[Vue]computed计算属性undefined的排错'
date: '2019-10-25 00:12:30'
updated: '2019-10-25 00:12:30'
tags: [Vue]
permalink: /articles/2019/10/25/1571933550635.html
---
今天在做表格多选时使用了计算属性获取element-ui表格的选中，但是发现怎样都取不到
下面是代码：
```JavaScript
 computed: {
    selection() {
      if (!this.isMounted) {
        return []
      }
      return this.$refs.table.selection.map(item => { return item.id })
    }
  },
```
控制台调试
![image.png](https://img.hacpai.com/file/2019/10/image-1764d201.png)
然后发现Vue开发工具中的错误提示
![image.png](https://img.hacpai.com/file/2019/10/image-72213632.png)
原来是因为我忘了给table加上ref了
```
<el-table
      ref="table"<!--这里忘加了-->
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      :header-cell-style="{ color: 'rgba(0,0,0,.85)',backgroundColor: '#fafafa'}"
      border
      fit
      row-key="id"
      :tree-props="{children: 'children'}"
    >
```
加上之后就正常了
![image.png](https://img.hacpai.com/file/2019/10/image-464bd52f.png)
所以在计算属性中如果出现undefined有时控制台并不会直接打印错误而是直接undefined

