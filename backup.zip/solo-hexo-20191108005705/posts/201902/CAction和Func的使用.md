title: '[C#]Action和Func的使用'
date: '2019-02-04 23:43:39'
updated: '2019-02-07 01:40:53'
tags: [笔记, .NET]
permalink: /articles/2019/02/04/1549294282380.html
---
在写代码的过程中经常用到委托，每次都要用delegate定义一个委托实属麻烦。现在.NET类库中就给我们内置了两个委托类型，基本够我们日常使用了。
**Action**

	class Program
    {
        static void Main(string[] args)
        {
            Action action = DelegateTest; // 无参数无返回值的委托
			action();
			Action<string> action2 = DelegateTest;
            action("有参数委托");
			Action<string,int> action3 = DelegateTest;
            action("多参数委托",6);
			Action<string,int,,int> action4 = (a,b,c)=>
			{
			  Console.WriteLine($"{a},{b}{c}");
			};
            action("多参数委托",6);
            Console.ReadKey();
        }

        static void DelegateTest()
        {
            Console.WriteLine("无参的委托");
        }
		static void DelegateTest(string str)
        {
            Console.WriteLine(str);
        }
		static void DelegateTest(string str,int n)
        {
            Console.WriteLine(str);
			Console.WriteLine(n);
        }
    }
	
**	Func** 带有返回值委托

	class Program
    {
        static void Main(string[] args)
        {
            // 无参数无返回值的委托

            Func<string> action = DelegateTest;
			Console.WriteLine(action());
			//用法同Action一致，但是Func有返回值
			
            Console.ReadKey();
        }

        static string DelegateTest()
        {
           return "无参的委托";
        }
    }