title: '[笔记]重装系统失败进入Grub查看文件出现Filesystem is unknown的解决办法'
date: '2019-02-19 20:34:29'
updated: '2019-02-26 17:06:24'
tags: [笔记]
permalink: /articles/2019/02/19/1550578760649.html
---
一直都有着把电脑换成linux的想法，但由于linux太多软件无法使用导致一直未入此坑。今日突来兴致想来个双系统，但因为没带U盘在那瞎折腾导致引导坏了进入了Grub模式。
**解决办法**

> 先输入ls查看所有分区类，和linux的查看文件类似
> 然后我们要在这些分区里找到我们WIN10的引导文件，在网上查找资料说是可以查看分区内的目录，但我的要么出现Filesystem is unknown要么是Filesystem is fat。但是知道了引导文件在```/efi/Microsoft/Boot/bootmgfw.efi```这个目录里接着就是一个一个试过去了
> 介绍一下Grub下我们要用到的指令
> 
```ls ```
> ```ls``` 命令 ，和Linux的ls命令功能基本相同。列出目录下的文件与子目录。在默认的根目录下，键入ls命令，可以看到打印出一串形如“(hd0,1)”的目录，这里的每一个目录就代表着一个硬盘的分区（不管是linux的还是windows的）。 
> ```ls```命令还可以用于查看任意子目录里的情况，如 ```ls (hd0, 1)/``` 可查看(hd0, 1)分区中的文件。
> 
```set root=```
> 和Linux里的终端一样，Grub的命令行也有当前目录的概念。```set root=``` 可以改换当前目录。比如```set root=(hd0, 1)```
> 
```chainloader``` 
> ```chainloader命令```是指定一个文件作为链式装载程序载入。怎么样，这个解释是不是说得云里雾里？但实际上，如果我们只是用终端启动windows的话，也不需要了解太多，你只需要用ls命令找到windows的bootmgfw.efi即可（一般来说，这个efi是在某个分区下的/efi/Microsoft/Boot/中）
> 
> boot 
> 按照当前设置，引导系统启动。
**方法**

```ls (hd0,gpt1)```
>```(hd0,gpt1) Filesystem is fat```
尝试
```set root=(hd0,gpt1)```
```chainloader /efi/Microsoft/Boot/bootmgfw.efi```
如果成功会输出一些路径信息，失败则会说文件或者目录未找到，这个时候就继续尝试其他分区直到找到了为止，如果系统没毛病大都能找到
最后
```boot```
启动引导成功进入系统
![imagepng](http://oss.loverot.cn//file/2019/02/ff92e9e511c74f3482f4ef7b40f4fcba_image.png) 
