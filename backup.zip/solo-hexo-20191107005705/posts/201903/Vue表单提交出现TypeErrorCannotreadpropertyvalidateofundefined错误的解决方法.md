title: '[Vue]表单提交出现TypeError: Cannot read property ''validate'' of undefined错误的解决方法'
date: '2019-03-15 17:51:06'
updated: '2019-03-15 17:51:23'
tags: [Vue, 前端]
permalink: /articles/2019/03/15/1552643268117.html
---
``` html
<el-form  ref="form"  :label-position="labelPosition"  :rules="rules"  :model="form"  label-width="80px">
```
``` html
<el-button  type="primary"  @click="addDormitory('form')">添加</el-button>```
```
```
    addDormitory(formdata) {

      console.log(this.$refs)
      this.$refs[formdata].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
```
 @click="addDormitory('form') 方法内传入的值为ref="form" 并且需要加上' '单引号