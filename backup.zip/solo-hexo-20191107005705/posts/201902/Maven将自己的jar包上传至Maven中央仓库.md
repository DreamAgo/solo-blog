title: '[Maven]将自己的jar包上传至Maven中央仓库'
date: '2019-02-26 16:51:20'
updated: '2019-02-26 16:51:20'
tags: [Maven, java]
permalink: /articles/2019/02/26/1551170237295.html
---
在项目开发的时候需要导入许多包，以前的管理方式是添加一个lib文件夹将包全都放进去然后引用，现在有了Maven之后方便多了，只需要配置一个pom.xml文件就行了，jar包都会直接在网上下载进指定的仓库文件。有时我们会自己写框架供自己使用，这时我们就可以将自己写的框架上传到中央仓库以供实时下载了。
首先我们需要在https://issues.sonatype.org 注册一个账号，之后登录发布工单
![image.png](https://img.hacpai.com/file/2019/02/image-397cb5e2.png)
选择开源项目
新的工程
![image.png](https://img.hacpai.com/file/2019/02/image-20c6c42a.png)
名字随便填
Group Id  *填你的域名反转或者是`com.github.xxx xxx`是你的github的账户名

Project URL  *填的是工程路径像`https://github.com/sonatype/nexus-oss`

SCM url  *填的是工程的git地址 像`https://github.com/sonatype/nexus-oss.git`
填完之后点创建等待审核完毕就需要配置maven了
我这是自己装的maven,但是IDEA自带
在这个路径`apache-maven-3.6.0\conf`找到`settings.xml`在里面添加
```
 <server> 
        <id>snapshots</id> 
        <username>申请的账号</username> 
        <password>密码</password> 
 </server>
```
然后在自己的工程`pom.xml`文件里把`<groupId>com.github.xxx</groupId>`改成你之前填写的`Group Id`
再加上下面这一段
```
 <distributionManagement>

        <repository>

            <id>snapshots</id>
            <url>https://oss.sonatype.org/content/repositories/snapshots/</url>
        </repository>
        <snapshotRepository>
            <id>snapshots</id>
            <url>https://oss.sonatype.org/content/repositories/snapshots/</url>
        </snapshotRepository>
    </distributionManagement>
```
之后使用`mvn deploy`就可以提交到远程中央仓库了