title: '[Springboot]整合shiro+jwt+redis出现部分Controller无法访问404'
date: '2019-10-20 16:03:13'
updated: '2019-10-20 16:03:13'
tags: [SpringBoot]
permalink: /articles/2019/10/20/1571558313117.html
---
这个问题也是很神奇,一部分请求链接可以访问没问题,有一些请求链接直接404,原因竟然是使用的这个maven包
```
               <dependency>
		    <groupId>org.apache.shiro</groupId>
		    <artifactId>shiro-spring-boot-starter</artifactId>
		    <version>1.4.0</version>
		</dependency>
```
换成`shiro-spring`就没问题了
```
        <dependency>
            <groupId>org.apache.shiro</groupId>
            <artifactId>shiro-spring</artifactId>
            <version>1.4.0</version>
        </dependency>
```
以下是更换前与更换后被spring管理的请求
更换前
![image.png](https://img.hacpai.com/file/2019/10/image-59bb6305.png)

更换后
![image.png](https://img.hacpai.com/file/2019/10/image-6b3f66a5.png)

