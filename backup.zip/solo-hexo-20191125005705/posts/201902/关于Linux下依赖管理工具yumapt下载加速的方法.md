title: 关于Linux下依赖管理工具（yum|apt）下载加速的方法
date: '2019-02-04 12:25:11'
updated: '2019-02-04 12:25:11'
tags: [原创, Linux, 教程]
permalink: /articles/2019/02/04/1549254311748.html
---
通常我们从官方下载的镜像在未修改仓库的情况下都下载的特别慢（大陆以外除外），对此我们大阿里专门建立了一个同步镜像站：[https://opsx.alibaba.com/mirror](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html)在这里我们可以下载多最新的镜像，每个镜像都有对于的修改下载仓库的方法。
就以Ubuntu为例：找到Ubuntu镜像，右边有个帮助

## [](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html#ubuntu)[](http://blog.loverot.cn/articles/2019/01/31/1548949095892.html#ubuntu)ubuntu

### [](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html#域名说明)[](http://blog.loverot.cn/articles/2019/01/31/1548949095892.html#域名说明)域名说明

对于阿里云ECS用户，可以直接使用内部域名访问，而对于非云用户则需要使用公网域名 mirrors.aliyun.com 来访问。

### [](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html#图形界面配置)[](http://blog.loverot.cn/articles/2019/01/31/1548949095892.html#图形界面配置)图形界面配置

新手推荐使用图形界面配置： 系统设置 -> 软件和更新 选择下载服务器 -> “mirrors.aliyun.com”

### [](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html#手动更改)[](http://blog.loverot.cn/articles/2019/01/31/1548949095892.html#手动更改)手动更改

用你熟悉的编辑器打开：

`/etc/apt/sources.list`

替换默认的

`http://archive.ubuntu.com/`

为

`mirrors.aliyun.com`

以Ubuntu 14.04.5 LTS为例，最后的效果如下：

```
deb https://mirrors.aliyun.com/ubuntu/ trusty main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ trusty main restricted universe multiverse
deb https://mirrors.aliyun.com/ubuntu/ trusty-security main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ trusty-security main restricted universe multiverse

deb https://mirrors.aliyun.com/ubuntu/ trusty-updates main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ trusty-updates main restricted universe multiverse

deb https://mirrors.aliyun.com/ubuntu/ trusty-backports main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ trusty-backports main restricted universe multiverse

## Not recommended
# deb https://mirrors.aliyun.com/ubuntu/ trusty-proposed main restricted universe multiverse
# deb-src https://mirrors.aliyun.com/ubuntu/ trusty-proposed main restricted universe multiverse

```

### [](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html#ubuntu-1604-配置如下)[](http://blog.loverot.cn/articles/2019/01/31/1548949095892.html#ubuntu-1604-配置如下)ubuntu 16.04 配置如下

```
deb http://mirrors.aliyun.com/ubuntu/ xenial main
deb-src http://mirrors.aliyun.com/ubuntu/ xenial main

deb http://mirrors.aliyun.com/ubuntu/ xenial-updates main
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-updates main

deb http://mirrors.aliyun.com/ubuntu/ xenial universe
deb-src http://mirrors.aliyun.com/ubuntu/ xenial universe
deb http://mirrors.aliyun.com/ubuntu/ xenial-updates universe
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-updates universe

deb http://mirrors.aliyun.com/ubuntu/ xenial-security main
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-security main
deb http://mirrors.aliyun.com/ubuntu/ xenial-security universe
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-security universe

```

### [](http://blog.loverot.cn/articles/2019/02/01/1549030722077.html#ubuntu-1804bionic-配置如下)[](http://blog.loverot.cn/articles/2019/01/31/1548949095892.html#ubuntu-1804bionic-配置如下)ubuntu 18.04(bionic) 配置如下

```
deb http://mirrors.aliyun.com/ubuntu/ bionic main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-security main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-security main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-updates main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-updates main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-proposed main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-proposed main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-backports main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-backports main restricted universe multiverse
```